<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Blog</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

    <style>
/* Dropdown Button */
.dropbtn {
  background-color: #694E4E;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
  width:160px;
  font-family:impact;
  font-size:large;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
  background-color: maroon;
  color:#49FF00;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #EEEDDE;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
  font-family:impact;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 20px 16px;
  text-decoration: none;
  display: block;
  font-family:impact;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

img {
    border-radius:80%;
}
p {
    color:red;
}
    </style>

</head>
<body bgcolor=black>
<center><div class="dropdown">
  <button onclick="myFunction()" class="dropbtn">Menu</button>
  <div id="myDropdown" class="dropdown-content">
    <a href="http://localhost:3606/PersonalWebBlog/mywebblog.php">Main</a>
    <a href="http://localhost:3606/PersonalWebBlog/signupusers.php">View Register Users</a>
    <a href="http://localhost:3606/PersonalWebBlog/about.php">About</a>
    <a href="http://localhost:3606/PersonalWebBlog/signup.php">Sign Up</a>
  </div>
</div></center>
<br>
<br><div style="background-color:#151D3B;">
<center><img width=250 src="https://scontent.fcrk1-3.fna.fbcdn.net/v/t1.6435-9/p206x206/211623246_4042536055783980_8329055633123992176_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=da31f3&_nc_eui2=AeFFXnWXPXDBsPT1PLFPymTovhL84Wy8DQG-EvzhbLwNAbycItTRjtxps5BrBrZe194AsF8c_CMPu4SdXz2iv5ww&_nc_ohc=5kFm5OHfuiEAX_j35t5&_nc_ht=scontent.fcrk1-3.fna&oh=00_AT9o6onxf3mieRPnBW46F8uUg8N4rtX9mNgq-K_Iug_szg&oe=6220BED5"></center>
<center>
    <h1 style="color:white; text-shadow:4px 4px 4px yellow;">Im Eduard Dueñas</h1>
</center>
</div>
<center>
    <h1 style="color:white; text-shadow:4px 4px 4px gray;">About:</h1>
    <h2 style="color:white;">Hi Im Eduard Im sharing a lot of tools in web development and to enhance your web developmet skills.<br>
You need to focus and analyze the syntax of every different programming language and always practice.</h2>
</center><br>
<hr color:white; size=7 noshade>
<center><h1 style="color:white; text-shadow:4px 4px 4px gray;">My Hobby:</h1></center><br><br>
<center><legend><fieldset style="color:white; width:40%;"><img width=200 src="https://i.pinimg.com/564x/50/ab/08/50ab0829f39f8179b1021d5100dec6e7.jpg"><h3 style="color:white;">Listening To Music</h3></fieldset></legend></center>
<br><br>
<center><legend><fieldset style="width:40%;"><img width=300 src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYVBxcUFBQXGBcXGxoYGBoXGhcbHBoYGxccHRsaGhgcICwkGx0pHhsaJTYmNi4wMzMzGyQ5QDkxPSw0MzABCwsLEA4QHRISHjQpJCo1NDM0MjwyMDIyMjI7Mjs0MjIwMj0yMjM2MjAyOzIyNDQ0MjI7NDIyMDszMzIyMjIyMv/AABEIAMIBAwMBIgACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABQYDBAcCCAH/xABGEAACAgECAwUDCAYHBwUAAAABAgADEQQSBSExBhMiQVEHMmEUQlJxcoGRsRUjJqGzwSVic4KSssIkM0NkdKLhNDaD0fD/xAAZAQEAAwEBAAAAAAAAAAAAAAAAAgMEAQX/xAAsEQEAAgIABAQFBAMAAAAAAAAAAQIDEQQSITEFQXGREzJRYfAUgaHBFSIj/9oADAMBAAIRAxEAPwCZ9mh/pe3+z/1CaOv4qi8a1G+zA3sACrDGCc89s3PZmP6Yt/s/9Qn5xt8a+37b/wCYy6k6lly/LCjazVJZ2lqKMGXcgyPUEywdqR/s3B/qT+NTIDXgntLVjrmv/MZYe0v+54L9SfxaZOyNPz3h5vbPFeL8umkv5/3VkznbwPUn00d38IyBJ/pLjB/5XUfniTdp/Z/V/wDRX/wpTKdPL1cGiIkGkiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgd99mp/piz+z/ANQmrxrVV/pKwGxM94495fpH4z37NzjjzD1rP5iZ+MD+kLftv/mMtjuzX7KBr7ge0lZVgR4OYOR1PpLN2nP6ngx9An8WmVfjh29oVP2PzMs/ao40nCD6Kn8WqTnyQj892tS+dbxj/pdR/nk/ef2d1g/5O7+HILS1HveKMej6O1h9TN/4MndSP2e1p/5O3/JK7J08vVwaIiVtJERAREQEREBERAREQEREBERAREQEREBERAREQEREBERA7v7Of/cDfYb8xHF9Wv6VsXvKvffd41yMMcDGes8+zY/0+f7NvzEluK1VniNmQp8bdQD84yy06lVFOaHMe0S7uLhlIPNACOfPn5j650N+CLqn4YrNha6e8YebbGrOB9ZEgNdfXXx3lWm7CshwAqNj39g5MQOnkDz54xLyA3cabVeIpTRY7sT1Gwk5znJMhOTfSFscPy6meyt8Wan5RxCvTI2F0liOxzgFCV2J5k7mOT/UwOpmTUjPZjXMOg0lgPwJUYH7jKDp+Mkamx27zFofIVsAl2JyRjn4iTMt/Ht2iavNqhlKkB12tkdHBXmv3yiM8eb0MnhlpmJpHT86ufxiTOpoVriwVUHou4gf4iTFVS55gH7hO/Fgjw++9TKHxMiUMegP4S9rw5a6xyXeeTAKGIOPgfu6cvyk+DUIdWqvd3C8mLMApYZxtXIU88dQ3LIlX6mZnUQ2f4itaza19/aIc4Thtze7U5+pSf5T03Crh1rYfWMTs/aRaquGA16hnY+EA23EYzzJAt+v93WUCzx6xa1Yu7sEUMWIBblnmx5c+s7bNaJ1pzD4divWbzMxHt/Sq/o2z6Bnn9H2fRP7pc9Tq1ThtqmzNb+DTI30BaGN2PIYUru6kufQyu260FiSwyfQH+U78S/0Q/R8Nrc2mP3hG/IrPomeG0rj5p/Ay36FFWhFIGbEa+52UN3WlUkDarAjvHI5Hr4kA94yuJxQjovnnq2R8MycTf6Ms4+H3Mc0x9+7RNTfRMx4lx7N8Tst161ojnqWJsQIiDmzuXRgqKMkk/v6Sxji+kbQvcyI1C2ilXs01O53Klsr3YQhQoGc8xuX15Oe0d4J4fDOuW/vDlc/Z0urQcO1Qbu1rGAWYq1lWB6kWeEDPxxK7xzs0lbHuLN/M5U4JAGcnI8uUjGeu9TGkp8PyTWbUmJ9FUiD1iXvPIiICIiAiIgIiICIiAiIgdw9mzftH/8AG38pKcVsX9J2eJfffzH0jIP2bP8AtMo/qPLPxGtG4lYCBne3l8TJ5IV47Ob9obcce8J+YMfXtnTdXqivspd/P5Kw/wASlf5zmPa1VXj5xgDYOnL5pll4nfbrexlWj0obaqBr2IIAFeTtJ8x4c/E7R6yiJ6y35Kzy1lzKhyKh9Xn6ZM8sZuEAacDAzNfZlvx/KZdxMvepW0V1LyjYBz5gj/8AfhPCe8Prmvr7wDhTk+Z9D6CZuDsWW4nmy0s6A/SDLkj4hCx+6W1xzMbYcvG0paY1vSUbUNk8/M9Pifylr4DxJ1qLG1iCFRazkoBkljgnk2doGPjIDT8PTu6RY5V7HrrboFV7K2sUcxywGoBPlub0m/qR8l4QLWyT3Oms2tyPe6hrP1fwCpU59eUr+DeOzVPiPD3iItM+XkleIXBmyUT/AAr/ADErWrwLMqqqfIjkf3RxTj5TT0OEDC6rvOpG0i2ysr054Nf75pcZ15rFRwCbK97D6LCyysr8cbOvrmV1wZN9YXT4lw3LqJ/hr3jNrlzkqoIJG4nmqhefQAH92JqhAfIfgJLcd0Bo4NTbcGW27cUr8OFRdpy5zkEq6kLgHnk45A+BolXXmokk00PZqOYAWxUZhWvXGGKVt18W7HlNHJbTzZ4rDzTvrHo8m5npZGOVbZuHIbhWmysHHUKvIDoJn4fwiq3UVVKF7yx2QKfTC7T95LfVtldHEm+H4To+k0D09mjqu4J11lPcV1rjciM21tQE67+7esHAJUupPvEKjFbfWf5Sv4hgrX/nSJn7xGkTw+utdBaFCishO/O/Axu8CvtBx4vLzI+HKU4a2jtevTgadjk92m7VuATgsQBhVztyx5DABJwOVL4/cK6l0VRBSo5tYcxZqcYZs+apzRPgGPzzLDw5l4bou7Srv+JalQO72lxp6mGQhrHvWsMEr5DAIxkNKMH1mWe/iW+1Ij0W0cKr+QM4GnRFq+UAhB46VXJdQWZyAGHPbjJx1lQo4ql+nv8A1RFKU2F7HwNrGthUAAMbms2ADPPxeQJFn4mw0fYu2vXWWanU2Gu22s2YVe9fw096Mtg90zlVIz3R5gYJ5dxXjVl6qhCJUnuVVLsrTPUhepY+bMSx9Z2MFN7lXbxLPNZrvUSioiJcwEREBERAREQEREBERAREQOwezJ89qV+w8luJ8YqXj9qvfSu13BBdAQQ5wCC2QcY8pB+zFv2tT7D/AJSd0XfWdqdYzhRTVc6rybLtnpktjAHXl6CaLx/syx8qQ4ZoETirXuqWvYqqgZQwVMDmP6zH931mW/iFaV8FtwqoCjA7QFG4qQOQ88kCafBeH7tR3zdByQfH6UgvaRxwVabYD4U8dnxPzU/f+8SmYjfRopa3e0uLcRcV6VSQd7HK5xtKeIMfXO4AZz6yJbiDFcAAfHznjWaxrHBY9BhQOgG4tgfeSfvmr5SmuOsR1h6GbjclrTyzMQ/Cec2+G6o1a1HADYOCp6OrAqyH4MpKn4GakzaP/wBUn2l/zCWMK4+0GjYRhw4fU6t1IzyUdzWEOfNDWy/lyIkp25Rm4fpdL3gOoaqm+xW62EUitFDE47wHvTt+dv8AXkXH1W7jKaGxgq2vqGrY/MvPEdUoyfJXVQh+Ow/NkH7Tbt/abcOhrrI+AILY+7OIHvTaRbeGcP7weCp9ULuRyK6WS5wfQ7bCPrYT3wSxdVxSi+1A3ctqHsT5rbVt1dalfos/eL9Qm9pDdb7Nr3KguHHi+e9OF71jg8yDSmW81rbOcGVzsVfYvaakVAMXYI6t7rIff3egC5OfLGZ0Tus1LDhGl1eoy7ott67v+JqL9RZ3Zby2gUmwjoQqr86VvhlxOi1rMSWalckkkknV0EknzJ5ye9px7vi1emQEU1VIaTz8aMigPz/qoqn+sjHqTNLsdwwPXddYu5AjJWhOBdqAO8SrHVxlAWUYOCOYyMht9kOCKpGq1JCqim1FYZC1g4+UWKeq7vDWn/EfHzQxOU9obDrm4kBm3edPoqzufaOtjNzy52WYP0nvLeUw8ea3KcPXdZqbWS3VkYy95X9XRy5BKlOMe6GLdAom63D2r4hpdDpm36g1oHuUgrp1tdrHZMct2x1Jsz7u0DBGYEnw3hGm0PFbtS2FFSrYneqWWg2qGqqC5zbcMnPPAVeoZtyb/AdSKNAdTXT+v1hcUC0g337jusvus5CqrHiIXAC5JJLK6xtho1XFn1D4ThmiISsMdq6ixFCIucEkbEXOAx2KAF3PKz2l7VNfqLNhP6wbXsI2s6A5FaLk91QD0QElurFieXBr9q+M97d3SOXRXax7Dy7+5gAbAvza1VQiL81R5FiJXIiAiIgIiICIiAiIgIiICIiAiIgdX9mDftcn2H/KdTbRB+IMijC7izY+JyT9ZM5R7MOXa5Psv/Kd0rqAYkdWOTL8s6sz467hrcQ1S0aAtj3RhR6nyE+efaLxg2aoUhsnPeWH1duYH88fEek6p2444tauzHwUqeX0rDywPvwo++fPWqvazUM7nLMSx+smVT0hbHWWCIiRTJ7R8OCOoII+6eIgdK7SWIO3+7aGXT02X4P0mW3VJ/3WpNbtcmmv0uj1d91tb36dd3d0VurPW7I552ptOfLGOnOTvFtPpdTxxGWy1G1mlFVdvdqabiK1BYOH3B1wFZCoxtwcZBPmvs3RZodLRXqksfQ2F7B7jNS794yrWScOGGMEjqfqgaFlFul1Y0ye58m26dwVYPqNO5vsVlVjtYs11TITnx45iaSFNHwZ+I0Vsj6sGuhGXcNOCT3zbiMOpwFQnqCwOcHLsdY2t19ocurrqE1qug3Yfee8Tnyy4bw/FB8Zrds9aU7T7c79M1NFdaoAEag1ggV+u1y5B+kD5coGTs/YOJcIOhvY95RuupuYFyKywNyHHibrvA88MOu2Z7UariD6h1xp9CRXoq/eWy5/FUwxyfdjvnbqQAPQCPqru01+n0+jUvfY62l1HN2rsPd1geSLtDtnzPPkuTdu0GkVrE+ShHrpruOiCsGV9UxZrFXxEE1qpKKRjwKvmMhT+M02VcMNqgfKdRa1OpKYyjmtH7tCDyazexfHQgry5g9C4VwKtNNqmZzW9tdNZfHjqqXT1ptB6KxQsc8gMDPISgdhKnv09oAL2V2LqK84O67u7FUEk5z3jVuT6I0nfan2jC6f5FU2LGbdfjkQmwbUJ9Wzk+e0KCSCYFJ7X8ZTUaxa6AE0tAKUIARy5bnOee5yAefPAUHmJXYiAiIgIiICIiAiIgIiICIiAiIgIiIHUvZkf2vr+y38p2njGu7rRk/Obwr9fr904h7MW/a+v7L/AJCXvtzx5atI155hAVrU/Oc8h+J5/UJoyxuyjHOocx9o3Gd+rGmQ+GvxP8XI5D7gfxPwlGmW61nuZ2OWYlmJ8yTkn8ZilEzuV0RqCIicdIibWj0Nltm2qt7GJwAiljnazYwB12qxx6KfSBefZP2jp03EHq1LhUsatqy+4otgJUnl7hKtjdjGBgkCT/COyF3D+May5GqtVaTsO+tTuN9TMrqzeDCK4J6YPxxOOz6D7GWVP2Z+X2BALUPyxrBkM1OyoEjoQUWxsdN1kCqduNM1V/c6RhVernU2opCtbubwbSMK7V7TlfMknmZpaU97V8usC10guzI6jFeq3KXekuCVRmy+0ZG7w4zgyRu0FfEOB2XnUZqrus1aW4xdTW7F9Tp3rGeakq6kEg7s8hylfo7R/KQ9KJtIDd1WzMy3V9WqtBJw5wWVhjxZHziYEhVWlmh7vQWtZQ3hvwGTU1M2Abny2HqJznGFAODjrMdGtt0fElAetdDSECh/GmpIG8W1qOZsZn3B1wUGAT4SDip0S8O0R1yJZ+sVBXXYmdgcMTXacYIYAHPLcvlzON+rh667i1KFFWgomoobbjYh8D6XevLuxYrYz02nn4jAtINOj4npVqrCrqrsVVqoUlGrrdrLMcnYMwVcnaoYkDKjHJ+34I7Z6sEYxawHPPhHJfu2gTqWh4jVqjazqV/RV1hUY8fdLU67mQ4PNwzEDphR5TmXtGcN2wuYfOFTN8WalGYj4ZMCrxEQEREBERAREQEREBERAREQEREBERA6V7MDntfWP6ln5SN9p/HBdxjuKzmukkH42H3vw6fjIfgPaV9LxDvkQFgjqvPoWGA3xx6SCssLOWJySSST5k9TLcl4t2V0pMd3iIiVLCIiAlo7CdpjoeLlyzCuxSjheeD1R9uQCVbH3Fh5yrxA7vd2b0PEtOutYKQGbL0nYLevhtTAYFeRLcm29efSx8K7O6Ednzo0rVtNqAHJV3YWP4csjFiVwVXAznI6eZ+dRxW0cGOkD/qTZ3xXA5vtC5J64wBy6cszc7OdqNTodUHotYKCSa2LGtiRjLJnBPx68oHahRrNJqaaKqqDW1xzVU1dddelAZVADsLLLXLb2bnkoB6yN1fZ7R6bi9t6aVO9qKkB91en3kOyDTCzwPZyTdk7E6gZGDXqfakl96163Q0NUz+IsN4TJ98IVJJHMnnkyZ7TnXWaoavh2sCIUAeoX0iuupMgXKxIQ1nBJyA6nljHQIo0ai7WHV1VotdqtRxCjUsFppFe3mztzVSpV1KgkNkjqBMh0K19nPkVVrGzUiz5GzqUBywL1E2Y2G2tgFyBkk5xnnufpTTHQMms1elt1NylnRHLaY2o4amyx1GxCCArhT4lz1wJH18AP6a+Ta7Vra+qdLglSW4a0MMd3bsChdgZCV5KCOmIG3wfivyfhI112mY26i2vQ6tHJXKojo9hXHJ2wgYEe8h6bjKh7VOH9z2uYD3XrpKZ67UqWo5PrurbMvtmt0ut7U2aO2+1bFrGndArPXZZS/e763B3K6OjKSwO5V65Mh/bhVmzS3Z9/vFx6YWpvD6jLMfv+MDk8REBERAREQEREBERAREQEREBERAREQEREBERAREQEREBESd7LdmrddxHuqhgDBdyDtRc9T6k+Q8/qBITMRG5diJmdQh66yzhVBJPIADJJ+AHWT/CeH6+jUi2iu2tsYyV25XIyGDdV5DkfSdr4f2Po0WhU1VjvFwTYwBdz58+uD6DlPGv8S591CM8+pH8vzmXLxE17Q3YOFrk+afZzezhmhv8eoqv0Vhb9YNOnfUYxksqrk1c8+HmB5D0s+j4Ts4FZpuFXJduVmr1Hf0mxLGADVJVgGkPXkbs5BYk46j811dbN4cDH0f/ABILi3Zeu5N9bbLRzBwVDEdMn1+Mjj4vc6tC3N4dqN0nf2SvZ/srfXqBrNbp3+UUKbNtbiyy4Bdqg1KGHedAG3DOclSQScfb25uIdgq9Z3fdWaa1kvqZSpUvsU7d3PHOs/3j6Tnep4rrKs0NqNQu1txQ2WYDg7t2M4znxZ8+Rmw/au9+E3Uah7L+9WtVay1m7vZYHyAc5z0PMeXpNbzJjU6lXYiJ1wiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAn0l7N+z66Xs3WrD9ZYO8s8vEwyFP2VwPuPrPnfhtQfiFaN0Z1U/UWAM+mDqvHtBwq+8fX0UfzlGa/LMQ0YcU3idJnWn/Zzs2gdMn+XrOd6/UouqatibD1QdftDYPQ/nJXtBxhhSqKcM5CKPID1+qU7iesCf7vqhznzc9CT9fOZ8t4v2ejw2K2OOqROuG/BBUfEYEm9HpC1eRzEqvDNUHcHOQZ0XgrImiJTGfNT0/u+hlWPHW06no0ZstqRuOrlXtN4KPky6lRgoQr/ABUnkfuPL+9OZzu/bXZZ2d1BHTYx5+RXmPvyJwebeHmeWYnyeVxtYi8THnBERL2MiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiBkqsK2hh1BBH1g5neNPxhLOHJYp5ON/3tzOfiOn3TgksfAOPGvSmlj4c5U+hPUfUTz/GZuKxTeu48m7gMtaX1btK38Z4rnii8/cR2/wC0j/6lSfixOo5ev85qa7iJbVM2feUr+8GaNfvyFMWq9WvJxG7TFfqu/BbtmrKeR8a/Ueol70mq/VgZnNtE+aFYe9Wd3909R+Utul1irXvZgFAySTgAY85lvOpbKxEsPb7Xd3wV8HnbhMepyCT/AIQw/Ccjk/2r44dVr8jPdpkID5+rEfHl9wkBPQwUmtevd4nF5YyZOnaOj8iIlzKREQEREBERAREQEREBERAREQEREBERAREQEREBERAREQPYebK3rjoZpxIzWJWVyTXsnNLxkIPdJ/AfvmnrOK2WVhC2FHkOn3+sjxP2crirE70nfiMlo1M9H5ERJqCIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgIiICIiAiIgf/Z"><h3 style="color:white;">Playing Basketball</h3></fieldset></legend></center>
<br><br>
<center><legend><fieldset style="width:40%;"><img width=230 src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUWFRgVFRUSGBIYEhgYGBkYGBgYGBgSGRoZGhgZGBgcIS4lHB4rIRgYJkYmKy8xNTU1GiQ7QDszPy40NTEBDAwMEA8QGhISHjQrJSE0NDQ0NDQ0PzExNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIALcBEwMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAACAAMEBQYBBwj/xABCEAACAQIEAwYDBQYFAgcBAAABAgADEQQSITEFQVEGImFxgZETMqEHFEJysSNSYoLB4RYzktHwc6IkJUNTY7LCFf/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACMRAAICAgICAwEBAQAAAAAAAAABAhESIQMxIkEEUWETgTL/2gAMAwEAAhEDEQA/APHZ2KKdghTZdn6f/lePdNKvxKCuRv8Ad73I8ib362mNmy+zc52xWEO2JwjgfnTvL9C0iXQIy86Jy3Xfn5xylVK9bcxci/tJLf4CIYU9D/aPlgRe459zO5N977bx5HXXVLE2bv1SbDbblfwvB6EpX2RMp6H2iljdStwoILaL+2Obz1tz6yEys1rJbpYHUf1kp2U0ADCBnRRe18rW62Nof3V98jgdSCB7mGh0AISmBadEYDpIvptyvOiNiEIgHAZ0NAEUBjoaGGjIMIGIY8GnQ5uCCQQQQQSCCNiCNQR1EZBhQA+g+xnFzicHTqsbvlKOerocrH1tf1nO0PERSpu99hp+Y7TEfZJxSxrYYnQ2qJ52yuB7IfWD2/4xnqCip0XVvzdPQfrJrZhJbozyVS7ljzMd4hXypaMYYW1lRxvHXvBbZb0qKLiVbM0iKIma5vCE1IFaK07OxAcyxZj1PvO3gs0ACp1HJADN7zfdksC7lcxJG58pk+CYEuw05z2Ds9w4U0GneIkSZXSLqlRsB5RR5UiiJPmCckwYTxnRhRNs0VgyFLrsdxD4GNw9TkKyhvyv3G+jGRBhB4QxhB1t49InONBiyf2rwPwMZiKXJa7kfkc51+jCVQmv+0UZ3wuKG2JwaM3/AFEGV/XUe0yEExho5XVSQfCS/ifKQbX379+Q35jb9IxhqRJuAfMW3GvOOYmoflBe1tiF+X05yq8dmcqcqRISoP3hrYXNRybX+UZRpvudtY58RbWDUwATYZ6h7x0uDbWVV4QMzaNYulRNbFKNAikdbv8Apm0ifFXv3EsbW3JFuhv+siTojSSC7JQxWoOSnsRbLob9QTF96NrZaY8kF5GnRGFDjvfU29BaIQROiIaDE6IInREMMTogCEIAFOiBeEDEMt+zuMNLEI4Nu9kJ8G0H1yyZxM/tGJN2zG/neZ9W6b/1ltxetfJU5PTDfzbMPeJkSWzr4qy2Ep8VTLyPXxkFMXCmFoNeGkxwcJaP4fHgS0ocTTwjtkuikHB3hf8A8V5o6fFE8JIHF6fhHskzC8Ac9YX+H3BG80q8ZQmwtLbCMH5CJsaIPAeG5ADbabvhTl5VYHCFja2k1eCwoUDSSKTH1pxR6KBJ8uZhOioJAvFea4GuRYfGE596Er5yP+aDNm7xNQV+Do348LjGQ/8ASrDMPTM1vSZETTdgz8SljsJzq4Q1EH/y0TmW3j3vpMwpiqtCux2k9tCFN+ZF7eIkpE5qMy317h0J5C59PSQY4j2PUdDe30j70yZR9osKVRrXGZtABZKYAHhcH+8cxDvY5WIGgYlqe/MDJ06+ciouYghRrpYIxANx4+NvSTFoOtzkqWXvG1JVGXmTnve1xp43mbjTKjL0yE+GYEBmS5tu42IuDeEMMLEl6ds1vxH10EsEwz2vZspJsQ1JQVN7W/dO3sY3WBuA5DHX/wBUEHpcKNDtDbKuKIQppYHOL6aZW063hslMbOzHwS31JhOyahKQJ01DO8Ih9T8AAAHXI5A21uTDYWiLEJPFGqzACkoYC/yBdNrm86adVbAtTW5t8yfryj2O0QbTokmphyLhnp36Zr6jygLRTnUXbTQm8YkxoQhHMiad9j1su3vOPk0tnPW4A9oh2CJ0QbzogMJTJmKbNhj1pVP+x9f1zSDeWHDe9npnapTZf5gMy/ofeBMujNE3hAQbEaHcGx8xDEozOqIQMEQ4gFmPUxAnbWIKekuez3CWq1FW259hziYE7s1wZnYEiek4DhgAAAjmB4YtNQqjlLzC0LCSDZ3B4UKNpPWCqw7REiinbRQA+Tooop0lHIjFORgaLsHjPhY/DuflNUU2/LUBQ38O/f0jPHsF8DE1qP7lZ1H5b3X6ESDQBUBhow1B6MNQZq/tGQNiKeJX5cVhKVb+fLlf9FmLdyKqkZMQoIhqbEHx84wJNG2XV1Go0zsNNyCoH1iOKN9ACdRmOZt+YDGO5i47ucqBY3CKNdwPUjz6wFRN8o2/G4FtbHQb8+cctURF7dg/euYSkNb6Iu/jeH9+fSzWsbjKFXUbbDWSFRPmtTy/Lb9o1yeYa2uv6QkpgXvcA2BIpWs2gAux0vv5zK/w2pkVcdUzFg9QMbXIJBNttoi9R+dRr8rsfpJjpWY3XuhSNT8NLEDfS3JvrGRnOprKL9XO17cvWOxUR3puNWDDz/vGwJIyKbFqmptfRiR5zhWnbRnJ/KAP1jsKGRCEcV0/dcjl3gP6Tu+yb6Dc/wDDGgY2J2OjCvYnIbDe+loX3NrXJQD8wgOxm86ImW3MHynAYAmdj2HqlGDDdWDDzBvGYSmIZN4rwwfFZl+R7Ov5WF42nCryfWr/APhqb/uMaZ8hqn0IEiJxMCTsjQ4nB5JTgwkccZAnH434x7FonjhK+E2HYzhoTM9tdh/WYLBcTLtaeo9nBakvU6xNg+i6pJcyyRLCQcILmWQERmDaEBFaEBADloodooFHyaKRhrhzJtxOfEE0zZpiiOMLDXCxw1RDo1LmS5SGkjhS2k1XGafxOE4Wru2GxFTDt4U376f/AJEzTLrN1wTC/F4fjcPa5NFayD+Okb6eentIyqS/SnG4v8POBOicUzs2MglOoOntf6S0oKgJDfGudRkRAcxJ5Py326e1fQS53W38TZRrfW/hHcQwPyhDoB3SzEAeJ2vHXiRJ3JIn1MpLANUs1OwFSqikMvMhbjLtppztOVaiNe/wlPd1z1HvYa2FrEbeUr0wjmxCNY7aW9deXjOnCvlzHKFuRqw+YAm3npI/01S0Pv8ACJ1ZrACxRBYnnoTeAppWXSoT+LVQLW/D6xJhQSAXTUE6Bmt7CcVKfNn5bKNeo1OkeQYh/GSxApjUmxZiSB000hNjNLCnSG2oTXTxJjaPTA+Sox8WAHsBG8pY91T5AGFiocbFOeg1voALHw6ThxD2tma1778+sRwzjQqRpfXTT1nfgaXLIPW59hC0OhssTuSfWdnGA5G8EQAOdBgXnbwGOXnbxsGFeIZbYHv0a1H96nnX86HX6H6TOXlzw3EZHRuQbX8p0b6ExrFcGqCq6KpsHNvI6iCM5KmVd4rzRYTslWfkZNTsPVJ6CFklV2foEsPOeu8N0RV6ACUnAuy4pWJ1aazC4OQ9jb0WOBTSTbRqglhHwICOAQwIgsMLAAbRQ7RQFR8k/EM4WMQitN9FWwSZO4WlzIZEs+DJvJm/EqH/AESCne9Z6H2EcLUQN8r3RvFXGX9SJg0Het4zccFp5VUjcEEeY1E4OeeNM7OKOWS+zzfimDNGtVonenVdPRWIH0sZGE1/2p4QJjjUX5MRSp1h0zFcjAf6QfWY8TtTtWcXQ7SqFTdbX8QD+sk/GuLgvcWLEsq3N+QGu19ZDkjBg5tOel8me3pLW9ESSq/ofQi+9O9jqSznzCjf9NJKVDYOqOEyXutEAAjqWJBG/PlI7Y5wEDNUBW7LYKhF7g6gXtvG2xtxbJfe13cgA/w3tfxkOJcXoer4ggWb4hVhoM6iz7k2Xle2kBKwvZaCkna+dyfS8aXGsB3Vprpa6oL7Wvc638Zz79U7vffughbEiyncC0MUVbJfwK+YWTITqO6qDu9C07UoVNc9amp5qXBPst5Byu3J2Pjc6w3wjqLsMo/iIGvS28NB5Buic6hbS+infob/AKzpaiLWFRt75iF8rWkSKUBLbEJplpqNNcxLXPWNvXJvoov0FhGZ2IKO3hQLzt4DO3hAwAZ0GIY4hnr/AGTpJXw1OsQC+XI/507pv7X9Z48J6T9l2N7taieTLUX1GVv/AKr7yWTJaNuuFA5Qxhx0jquDHUWIzBp0BJaU4kSOqIAEohKIgIQgB0CFEIoAKKKKAHyPeK8JqJBsZouzvCRUOs0nyRjHJmkYOTpGbyE8jLrhtPKtzNPjOBotrATmH4RmIUDSc0vkxcTePBJMouHoXcec9F4fSsoEZwnZ9UsbS1pUrTzefmU3o7OGGK2Z37T8JnwuGr21p1Hosf4XGZL/AOm3rPMgZ7X2mwnxeH4pPxJTFdfOkQzf9txPElM9T4ssuJM8/mjjNhyZh7BSdtQLmplF+dgPLn9ZCvCRypBG48Af1nTF0YSTaH1phtcwF7aAMxEkJhVI7q1CSdAxRAQN9z09rwaYZ7MWtfQszhQDca6agAlpINJVYWegSbk5M1ZgALgEkW1/XeTJMcHsbKIDoKdhrZmLsdACLLvrcx0q9rUxmuS2ZUCg8iAW1O5hAEGw+MF3XRKVnOYsBfZdYxVVBoWQAtoMxqMoO5NrC8hK/Zq3XoFlf5XqBco2Z72ty7t9Y2ET8Tk6n5V+ve6xKtEXu1RtrZQFB6g5toqddFIIpqxF/nLEHXQkC2olUKwGZBsGO1rm3ncD0j4V2HcpWHUAm/qY2cU2tgiht8qjpawvtBeq7WBZyBtcmwhQBvh21LFVtfQkX05ACcFNBu9x/CCbe8LD4Go5ARHYkgCwJuTtPROFfZSzIGxFZkYi+SmoOXwLtcE+Qicq7BI86Bpi/dc9LkD3AjZN+QE9NxH2V2PcxDFejoL+40+kg/4HZGy/CqOeo299BEpJ+wejAqhkilg3bZGPpPS8P2QZRdlo0h1dhf6f7y0HZ6ki53qVGXpTpk/0PvC0Tk/SPMcH2cxVT5KFRgDYt3VUH8zEX9J6t2K7EphkD1u9iXWzWZsiKbHIoFs2wuTz2tLzg2Fp00zIKiq2oDm5Ntjl/Dfp7yajOWvpltpfe8zlL0i0m1sS8Np8lP8Aqb/edOFUbX95ICnrFkisVIjE20uYPxGHQiOvTjbpFbKqISYocwR9ZISop2IkFkEApDNicEWwilRqNiR6xCs4/EY80T/NltFKv70/Ue0UeaD+cj5tx1Ozt5zTdkmt7Sn4vQtVbzln2ecLI53cDo4dTNDjamvpLHglME3mdrYjM2k1HZ5LC886SaidiaLyullkemJLrtcSOk5G9lx6JWDAzhG+RwyMOquCv9RPAMfhDRq1KR3p1GQ/yMVv62vPX+OcXNLKEP7S4byAN/raYX7S8KFx7uv+XXp066+TrY/VTPb+HFxhv2ed8lpy0ZS86DAJA3Ik/BcGxNX/ACsPXe/NUbL/AKrWnYYWRkcAbLe4NyNfK/SE1ZiLFjb2v523mi/wXiUp/Er0nRAddVYgfvMVY5R5iDhOEoxsiPUb+AM59kEXYtGdNzvc+f8AeP08K7fKjH0NvfabzAdkcS3yYUoP3nyJ7gnN9JOPZrIuavjMHSUMFbKWrEMdlNstiYrQ7MBS4PUO4A8yP6XktOBAau4HkP6mbjFYTh+HcJWfGVSbWYDJRJIJAV0AY7Ntf5T0j+B4hRdSMHg8MldcxBxOd89NdijuFJc72PKKxbMhgeBI/wAiVah/gV398gtNHgexuIOow6oOrsi/QXb3EebtjiWIzkU8O6qrBGQsgLWZg6IuRhYizHS3OWfZLg4q1jiWq16tJGvR+KcxJZQQzE3a4B22719YnJpDSbLvhPZZKYR271RbG/4Q3gOkv2qOOQhJW1tHgQZi3ZfXojpiVOhBB8YVhOsg6QPSIevQw2HUG+VfYQmFxaOkQSkBjAax1F5ypxFF3IBjrrK/iHD0qqVceR5iJ/g41exqvx9AwUG9zbTUA8gT18IB48gBJa1utwBKLG8NqUkZUaq1h3EJQJ6lFVm/mPneVT4nGsVX7uoX8RFQG3kpGvvE9ezeChK7VHo9DFZgCCCCLg9RHjUHWZXgVF1XK7AC+gzZmA8e6AvkL+c0FFEUaanqdTCzOcEuh5zAEFrkxLAmjrCcyxM1oBrCAbDyzsZ+8DrFGGzxfj+FIqE20lfTuu00+PZXPjK58LLVNUwaadoreG1GNTvdZ6ZwoAIPKefph8rXE1PCsfYWMw54eLo14521Zo2aQsfj1poXO+wHVuQifFqAWJAAFyfCY3ifEDVfMdFFwo6DqfEzi+N8d8k99Ls35uVQjrtjWJxDOxdjdidf+dJaUMJRx4w1Gs2SrRfIDqBWwrG5phh8rrbS+hBPOURaFQrMjB1JDqwKkbhhqDPbrVI8177PXcD2fw1D/Kw9FOWYIpY26ue8feWQ8b2mY7O9tkqAUsTlSpyfZHPj+430/Saldb2voef6jqJDTIMnxbtc1BmV8JXAtZHYBkdjcWJUgLtsWv4SkpdsaldBS+PS4fXDEAhA9OpcaAsyt8KxtvvfflN9jsBTrIUqIGU8jyPUdD4zz/tH2CK3qUDUqdUYqCFHRrXY77xqhpoo8TxfG03Z6lSq7BAtSmzOUyE2syOxBVwN1FrNpYwcCuGxLkUMNkdksaYqNlDqLl0L9xyFF8j5SbEgkwMS9ZaCUL0iisbU8ueqnOxLglRfkDCw2OqBBQxFnwucNkZwrIeboRcg6nQgg9IyiVwpsQwfCoEaijM4zOaAzB1Ieylsjb2CgXLAnPaMYnCfEcmiMSUW7YhlpEObtmYVFV8hK6/hW55bAPOcKzhErMlNFulRKAR3qDYVSWIK3A1y732kh8Q/w74hKLqjBs1QgVKyXuER1GV1uPlsd4gO/DFe1OkUqZ1DszMGxIWy6VFoFQyBiB8pKg62AAnpPBsH93w9OiiKGCDMFFl+IdXb1JJkHg3BMMypiUXLnRHyJ3EXQWGRQL28ec0BdRMpSvRcVRSVuA1HfOcRURrWGTQAet7+st8DhnRcrOzn95rZvoAI796QfiHvHVqA6g6SUkui5Tk1TFacyw4o6M7AywSI4TFABhljTLJLxppLKRHZAdxKzGcOvcroZbwHktJjjJx6MUcS6PZpOocYtHuN4IMMwNiPCZoo/KzfQ+0Si/R0OcWtmyo8TUjeSPvq9Zh1aoBfK/tJCUsS+iI3mSAPrKSkZtR+zSYniItuJQ1ONM7ilT7zk6nkBzJkTiuDemhatXppp8oux8vOSexWA7prEHv/AC33y8v94SjStji49I0tHCd0XOtopIzRTLIdM8Ww2Nz631lrReY+lUsbiaHhWKzaX9D/ALzqlH6MIzrstRSBjiJaElvL/nWDj8QKaFja+y+cjd0a+LWSIPFMeT3L6DfxP9pTtiv1lfXxWYnWACfGdMIqKpHNKTk7ZdZr7bRBpDw1XS3SEakoB9nl92f7Y1MP+zqZqmH2y376eKN08D9JlnqyO9WFCPfeH8YpV0V6TZ0OhI+ZW6Ou4MsbT534dxerh3z0XKNz5qw6MvMT1Xst26pYnKlS1OvtlJ7j+KHr4b+e8zlElov+N8FTEIVJZTa11NtPEc5g+K8HfC2Ap0SP/cyM58iG0BnqCsDtArUlcFWAIO4OsSdAmeOY3CPb41VGINu8xVR4dxbaR3DV8S9P4VNarUUu2VEORb6k5gLD1M3XGezwAzUEp5hya7H+Uk6Sgw9TE0zdWJY6NTCnUeKgfWOykyvbGYtKYWm/wbbksHP+ixlXxjiGJINsVWdAu6dzM3MHLYrNxheClxnFLIeaOe6fEZdh4fQTjdkMzK7uqhTfJSQIp8GJuT9JGrNo8njVmFwmJxK4crZkQtn+IzXfxALm9vKafsrx/EogLipWpH5GUZif5r7ecun7PYdWz/CQsNswzW8gdpJz5RYAAdBpE2gts0WBxodQ1ipI+U7jzkovMd96INwbGT8NxjSze8kWNmhzRZpAXGKRoY4uIHWKwxZKYxpjFmgMYmCRxjGnM67gRh6khyotRGMSl1ImGxwZHO9rzeFpRcY4fn1A1lQlTKcdFNhscRzk5uKZEL5sth6e0rvuZWZjtRxC37MHzm62YNIT4h8biVUklS23IIN/U/1nrOBohEVRoABPP/s64fo1Zhqxsv5R/f8ASehhpzc0rdfR0ccaV/YcUbzRTKzSjwGPUahU3B1jSrDUT0Dgs1XDOIq4sdGkHir3urajx1lVTJBuJNq1w66/MBBDKas4U6Aaf835xp8dfS1oeKTrvK6rNI7JZYYSvr4ER96sqKNSxktXg1QJkh6sZepGXeNloqCx0vB+JAvOXjoRvOyv2hVKNqeJLVKWwfd0Hj+8Pr5z1vhnFqVdQ9NldDsQbz5mMseC8cr4V81JiBfvKdUbzH9YnG+gPpgGD8Nd7C8xPZTtzRxICk5K3NGO/ip5ibWlWDTJqgDtAdY7OESRkKrSlfiMNLplkepTiaLjIzGIpESNnImhxGHvKvE4SKzZNMZpYiP/AHo6a85AemRGnciFjxNrg611nataVPCsRdBJTPMJyrRUYbCdyYMG86DMrs1qjsBxeFecMaEVPF8qISAS1uU8exyO9cgizM9gOgnt2JpBgQZjcVwYCuHttN4ctXZD4k+jQcBoLTpKg2CgS2+LKik9gBH0rzmcrdm+JPzxSH8aKTY6PGVEdCxRT1Tyw1EMLFFABnFUrjxlLiEtpFFLj2JkWP035cooprIlDtoLLFFMxgkQIoo0B0mCZ2KUI4rEEEEgg6EaEHwm+7J9v6iFaeIJddAG3YdL9YopMkqBHrGA4wrAak38DLZWvFFMGM4RAYRRSRoZdJEq0ooomaRK7E4eVlfDxRSTZFngFsJKLRRTln2bx6OgxXiiklAl4y+IiigNIaNeRawvrFFEMjsIy1S0UUCkc+8xRRQGf//Z"><h3 style="color:white">Practice Coding</h3></fieldset></legend></center>
<br>
<hr color:white; size=7 noshade>
<br>
<center><h1 style="color:white; text-shadow:4px 4px 4px gray;">Web Development Tools:</h1></center><br><br>
<legend><fieldset style="width:40%;"><h3 style="color:white;">What Is Html?-Hypertext Markup Language, a standardized system for tagging text files<br>to achieve font, color, graphic, and hyperlink effects on World Wide Web pages.</h3></fieldset></legend><br><br><br> <center><legend><fieldset style="width:40%;"><h3 style="color:white;"> CSS is a computer language for laying out and structuring web pages (HTML or XML).<br>This language contains coding elements and is composed of these “cascading style sheets” which are equally called CSS files</h3></fieldset></legend></center><br><br>
<br>
<legend><fieldset style="width:40%;"><h3 style="color:white;">Javascript an object-oriented computer programming language<br>commonly used to create interactive effects within web browsers.</h3></fieldset></legend>
<br>
<hr color:white; size=7 noshade>
<br>
<center><legend><fieldset style="width:35%;">
    <form method="POSt">
        <h3 style="color:white;">Rate my website 5 is absolute & 10 is Good.</h3>
        <input type="number" name="data" required>
        <input type="submit" name="chicks" value="submit">
    </form>
    <?php
    if(isset($_POST['chicks'])){
        $var1 = $_POST['data'];
        $var2 = "/10/";
        if(preg_match($var2, $var1) == 1)
        echo'<center><p style="color:#49FF00;">Thankyou for trusting my website!<br>Admin:Mr.Eduard</p></center>';
        else
        echo"<center><p>Its okay atleast you rate my website.</p></center>";
    }
    ?>
</fieldset></legend></center>
<center><h2>Admin Messaging:</h2></center>
<center><h3>Chat Admin:</h3></center>
<center><div style="background-color:#151D3B; width:100%; align-text:center; padding:3px;"><br>
<center><img width=75 src="https://scontent.fcrk1-1.fna.fbcdn.net/v/t1.6435-9/166830514_3764229030281352_8415481293883687010_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=174925&_nc_eui2=AeGoY-P92VIEM_RtyQiZakwM_zpyY-XxGn3_OnJj5fEafZQdylLvgGFCJSKz2Qj3Lqa8AFpfGDyoPlq8Hzd8WQNo&_nc_ohc=1fI_eCbf6bUAX-Kk5d3&_nc_ht=scontent.fcrk1-1.fna&oh=00_AT9HfVanWMa2SwuVwB5aXP00oZ-Y8JQeoeFdYHzHzeEezA&oe=622B6B5C"><p style="color:white; text-shadow:4px 4px 4px yellow;">eduarddueñas</p><p style="color:white;">Chat me!!</p></center>
<br></div></center>
<br>
<form action="mywebblog.php" method="get" align=center>
<input style="padding:30px; font-family:impact; font-size:large; width:40%;" type="text" name="chat" placeholder="Chat here">
<br><br>
<input style="padding:5px; background-color:green; color:white; font-family:impact; font-size:large; width:40%;" type="submit" value="Send Message">
</form>
<center><div style="background-color:white;"><br><?php
echo"<b><font face=impact size=4 color=red>Your Chats:</font></b><br>";
echo $_GET["chat"]; 
?><br><br></div></center>
<br><br>
<br><br>
<br><br>

</body>
</html>