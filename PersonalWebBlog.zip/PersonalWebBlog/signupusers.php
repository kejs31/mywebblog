<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View signup users</title>
    <style>
        th {
            background-color:violet;
        }
    </style>
</head>
<body bgcolor=black>
    <center><div style="background-color:green;"><h1 style="color:yellow;" align=center>Sign Up Users for My Site:</h1></div></center>
    <br><br>
    <table style="color:BLACK; background-color:WHITE;" border="5" align=center width="60%">
			<thead>
				<th>Firstname</th>
                <th>Lastname</th>
                <th>Email</th>
				
                
				
			</thead>
			<tbody>
				<?php
					include('conn.php');
					$query=mysqli_query($conn,"select * from `userssignup`");
					while($row=mysqli_fetch_array($query)){
						?>
						<tr>
							<td align=center style="color:black;"><?php echo $row['firstname']; ?></td>
                            <td align=center style="color:black;"><?php echo $row['lastname']; ?></td>
                            <td align=center style="color:black;"><?php echo $row['email']; ?></td>
							
							
						
						</tr>
						<?php
					}
				?>
			</tbody>
		</table>
</body>
</html>