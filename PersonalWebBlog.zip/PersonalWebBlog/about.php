<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    

    <script>
        /* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

// Close the dropdown menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}

    </script>
    <style>
        img {
            border-radius:50%;
        }
/* Dropdown Button */
.dropbtn {
  background-color: #694E4E;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
  cursor: pointer;
  width:160px;
  font-family:impact;
  font-size:large;
}

/* Dropdown button on hover & focus */
.dropbtn:hover, .dropbtn:focus {
  background-color: maroon;
  color:#49FF00;
}

/* The container <div> - needed to position the dropdown content */
.dropdown {
  position: relative;
  display: inline-block;
}

/* Dropdown Content (Hidden by Default) */
.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

/* Links inside the dropdown */
.dropdown-content a {
  color: black;
  padding: 20px 16px;
  text-decoration: none;
  display: block;
}

/* Change color of dropdown links on hover */
.dropdown-content a:hover {background-color: #ddd}

/* Show the dropdown menu (use JS to add this class to the .dropdown-content container when the user clicks on the dropdown button) */
.show {display:block;}

    </style>
</head>
<body bgcolor="black">
<center><div class="dropdown">
  <button onclick="myFunction()" class="dropbtn">Menu</button>
  <div id="myDropdown" class="dropdown-content">
    <a href="http://localhost:3606/PersonalWebBlog/mywebblog.php">Main</a>
    <a href="http://localhost:3606/PersonalWebBlog/signupusers.php">View Register Users</a>
    <a href="">About</a>
    <a href="http://localhost:3606/PersonalWebBlog/signup.php">Sign Up</a>
  </div>
</div></center><br>
    <div style="background-color:#361500;"><br><br>
<center><img width=300 src="https://scontent.fcrk1-3.fna.fbcdn.net/v/t1.6435-9/p206x206/211623246_4042536055783980_8329055633123992176_n.jpg?_nc_cat=100&ccb=1-5&_nc_sid=da31f3&_nc_eui2=AeFFXnWXPXDBsPT1PLFPymTovhL84Wy8DQG-EvzhbLwNAbycItTRjtxps5BrBrZe194AsF8c_CMPu4SdXz2iv5ww&_nc_ohc=5kFm5OHfuiEAX_j35t5&_nc_ht=scontent.fcrk1-3.fna&oh=00_AT9o6onxf3mieRPnBW46F8uUg8N4rtX9mNgq-K_Iug_szg&oe=6220BED5"></center>
<br><br>
    </div><br>
    <center><h2 style="color:white;">About:</h2></center>
    <center><p style="color:yellow;">Its all about web designing and developing to share my information about web designing and developing.<br>Learn about html,css,bootstrap,javascipt.</p></center>
   <br> <center><h2 style="color:white; text-shadow:3px 3px 3px gray; margin:10px;">Visit My Social Media Accounts Eduard Dueñas</h2></center>
    <center><a href="https://www.facebook.com/heyitsme.esd/"><i style="font-size:26px; margin:10px; color:blue;" class="fa">&#xf082;</i><font face=impact size=3 color=white>Facebook</font></a></center>
    <center><a href="https://www.instagram.com/eduardduenas31/"><i style="font-size:26px; color:red; margin:10px;" class="fa">&#xf16d;</i> <font face=impact size=3 color=white>Instagram</font></a></center>  
    <center><p style="color:lime;">Programmed and Developed by: &copy;Eduard Dueñas</p></center>
<br><br><br>    
</div>
</body>
</html>