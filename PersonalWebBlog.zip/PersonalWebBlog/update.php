<?php
	include('conn.php');
	$id=$_GET['id'];
 
	$firstname=$_POST['firstname'];
    $lastname=$_POST['lastname'];
    $email=$_POST['email'];

 
	mysqli_query($year_conn,"update `userssignup` set firstname='$firstname', lastname='$lastname', email='$email', where userid='$id'");
	header('location:signup.php');
?>