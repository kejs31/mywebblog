<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduardBLog SignUp</title>

    <style>
        .MyForm {
         background-color:black;
        box-shadow 8px 8px 8px thistle;
            width: 40%;
            margin: auto;
            background-image:url("https://i.gifer.com/J4o.gif");
  
  border: 3px solid gray;
  padding: 100px;
        }
    </style>
</head>
<body bgcolor=black>
    <br><br><center><marquee direction="right"><h2 style="color:#5800FF; text-shadow:3px 3px 3px yellow;">Signup your information in the form at below.<br>Admin:Mr.Eduard</h2></marquee></center><br>
    <center><a href="http://localhost:3606/PersonalWebBlog/mywebblog.php"><button style="font-size:large">Back To Main</button></a> <a href="http://localhost:3606/PersonalWebBlog/signupusers.php"><button style="font-size:large; margin:10px;">View SignUp Users</button></a></center><br>
    <form class="MyForm" action="add.php" method="POST" align=center>
        <center><h3 style="color:yellow; text-shadow:1px 1px 1px white;">Sign Up To EduardPersonalWebBlog:</h3></center><br>
        <input style="padding:7px; width:50%;" type="text" name="firstname" placeholder="Firstname" required><br><br>
        <input style="padding:7px; width:50%;" type="text" name="lastname" placeholder="Lastname" required><br><br>
        <input style="padding:7px; width:50%;" type="email" name="email" placeholder="Email" required><br><br>
        <input type="submit" value="SIGN UP"> <input type="reset" value="CANCEL">

    </form>
 <br><br><br><br><br><br><br><br><br>   
</body>
</html>