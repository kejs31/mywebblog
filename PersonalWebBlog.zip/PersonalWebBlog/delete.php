<?php
	$id=$_GET['id'];
	include('conn.php');
	mysqli_query($conn,"delete from `userssignup` where userid='$id'");
	header('location:signup.php');
?>