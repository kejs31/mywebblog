<?php
	include('conn.php');
 
	header('location:signup.php');
 	$firstname=$_POST['firstname'];
     $lastname=$_POST['lastname'];
     $email=$_POST['email'];
	


 
	mysqli_query($conn,"insert into `userssignup` (firstname,lastname,email) values ('$firstname','$lastname','$email')");

?>